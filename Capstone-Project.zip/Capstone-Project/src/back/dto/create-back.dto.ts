export class CreateBackDto {
    muscle: string
    equipment: string
    description: string
}
