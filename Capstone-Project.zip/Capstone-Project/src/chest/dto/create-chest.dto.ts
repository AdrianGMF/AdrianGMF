export class CreateChestDto {
    muscle: string
    equipment: string
    description: string
}
