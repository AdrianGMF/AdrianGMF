export class CreateArmDto {
    muscle: string
    equipment: string
    description: string
}
   

