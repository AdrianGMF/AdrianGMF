export class CreateLegDto {
    muscle: string
    equipment: string
    description: string
}
